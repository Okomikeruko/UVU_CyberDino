﻿// Name: Samantha Spray
// Project: Cyber-Dino Racing
// Date: 12/4/13

using UnityEngine;
using System.Collections;

public class OldProjectileMG : MonoBehaviour {
	
	// Update is called once per frame
	void Update () {
	
		//FireProjectileFunc();
		
	}
	
}
